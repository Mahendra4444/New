﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public string textfromForm1
        {
            get { return txtWorld.Text; }
            set { txtWorld.Text = value; }
        }
    public Form2(string txtData)
        {
            InitializeComponent();
            textfromForm1=txtData;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
