﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private string txtboxSecondForm;
       
        public Form1()
        {
            InitializeComponent();
            lblData.Size = new Size(25, 13);
        }
        
        private void btnForm1Hello_Click(object sender, EventArgs e)
        {
            string text = txtHello.Text;

            // Open Form2
            using (Form2 form2 = new Form2(text))
            {
                form2.ShowDialog();
                txtboxSecondForm = form2.textfromForm1; // Retrieve text from Form2 after it closes
            }
            txtHello.Text = txtboxSecondForm;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked ==true)
            {
                lblData.Text = "Yes";
            }
            else
            {
                lblData.Text = "No";
            }

        }
    }
}
