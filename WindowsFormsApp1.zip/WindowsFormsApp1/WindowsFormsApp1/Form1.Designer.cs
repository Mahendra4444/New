﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnForm1Hello = new System.Windows.Forms.Button();
            this.txtHello = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.lblData = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnForm1Hello
            // 
            this.btnForm1Hello.Location = new System.Drawing.Point(177, 36);
            this.btnForm1Hello.Name = "btnForm1Hello";
            this.btnForm1Hello.Size = new System.Drawing.Size(100, 27);
            this.btnForm1Hello.TabIndex = 3;
            this.btnForm1Hello.Text = "Hello";
            this.btnForm1Hello.UseVisualStyleBackColor = true;
            this.btnForm1Hello.Click += new System.EventHandler(this.btnForm1Hello_Click);
            // 
            // txtHello
            // 
            this.txtHello.Location = new System.Drawing.Point(50, 36);
            this.txtHello.Multiline = true;
            this.txtHello.Name = "txtHello";
            this.txtHello.Size = new System.Drawing.Size(100, 20);
            this.txtHello.TabIndex = 2;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(48, 103);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 17);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(174, 107);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(30, 13);
            this.lblData.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 196);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btnForm1Hello);
            this.Controls.Add(this.txtHello);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnForm1Hello;
        private System.Windows.Forms.TextBox txtHello;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label lblData;
    }
}

